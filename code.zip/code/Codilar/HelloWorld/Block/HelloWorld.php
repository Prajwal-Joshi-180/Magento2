<?php

namespace Codilar\HelloWorld\Block;

use Magento\Framework\View\Element\Template;

class HelloWorld extends Template
{
    public function getTitle()
    {
        return 'The time is: ' . date('Y-m-d H:i:s');
    }
}
